var reportIds = {
  "48": {"name" : "Summary of Climate Change Expenditure"},
  "602": {"name" : "AT GLANCE"},
  "1021": {"name" : "ADAPTATION"},
  "1368": {"name" : "MITIGATION&#x27;"},
  "1437": {"name" : "SUPPORTING AREAS"}
};

var order = {
 "0": "48",
 "1": "602",
 "2": "1021",
 "3": "1368",
 "4": "1437"
};